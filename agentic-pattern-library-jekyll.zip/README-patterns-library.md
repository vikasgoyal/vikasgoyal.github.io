# Agentic Pattern Library: Jekyll setup

This folder mirrors the root of your `vikasgoyal.github.io` repo. Copy everything into the repo root; the folders merge with what's already there. Nothing existing is overwritten.

## 1. Copy the files

```
_config.patterns.yml          → settings to paste into _config.yml (step 2)
_data/patterns.yml            → families, maturity levels, DoF axes, meters, card sections
_includes/patterns/           → small reusable pieces + one SVG diagram per pattern
_layouts/patterns-base.html   → page shell: your GA tag, site header/footer, SEO tags
_layouts/pattern.html         → the pattern card layout
_patterns/*.md                → one file per pattern (39 files)
agentic/patterns/index.html   → the catalog hub  → /agentic/patterns/
agentic/patterns/template.html→ authoring guide  → /agentic/patterns/template/
assets/patterns/              → patterns.css and patterns.js (shared by every page)
```

## 2. Update `_config.yml`

Your current `_config.yml` has only `theme: jekyll-theme-leap-day`. Add the blocks from `_config.patterns.yml` below it, so the file looks like this:

```yaml
theme: jekyll-theme-leap-day

collections:
  patterns:
    output: true
    permalink: /agentic/patterns/:name/

defaults:
  - scope:
      path: ""
      type: patterns
    values:
      layout: pattern

exclude:
  - README-patterns-library.md
  - _config.patterns.yml
```

Then commit and push. GitHub Pages builds the pages automatically; the first build takes a minute or two (check the repo's **Actions** tab).

## 3. Write a pattern

1. Open `_patterns/<name>.md`. Stubs contain only the header fields.
2. Fill in the sections. The full field list is on `/agentic/patterns/template/` (with a copy button), and `_patterns/fast-slow-escalation.md` is a complete example.
3. For the diagram, add `_includes/patterns/diagrams/<name>.svg` and set `diagram: <name>`. Use the existing SVGs as a starting point; the CSS classes `nd`, `nd-a`, `nd-g`, `t`, `ts`, `ln`, `ln-a`, `ln-h` give you the library's colors.
4. Change `status: stub` to `status: full`. The catalog shows a "Full card" badge automatically.

## 4. Add a new pattern

Create `_patterns/<new-name>.md` with the next free `n` number. The file name becomes the URL. It appears in the catalog, the filters and the previous/next links with no other changes.

## Notes

- Prose fields (`problem`, `solution`, forces, example steps) accept Markdown, such as `inline code` and **bold**.
- In `related`, `pattern:` is another file name without `.md`. A link to a file that doesn't exist is silently skipped.
- If you ever change the URL path, update both `permalink` in `_config.yml` and `base` in `_data/patterns.yml`.
- To preview locally before pushing: `bundle exec jekyll serve` with the `github-pages` gem, then open http://localhost:4000/agentic/patterns/.
- Consider linking to `/agentic/patterns/` from your Agentic AI hub page (`agentic/index.html`).
